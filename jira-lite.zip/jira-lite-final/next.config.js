/** @type {import('next').NextConfig} */
const nextConfig = {
  // Allow server-side file system access (for CSV layer)
  // When upgrading to a real DB, this section can be removed
  experimental: {
    serverComponentsExternalPackages: ["papaparse", "bcryptjs"],
  },

  // Redirect bare "/" based on role — handled in middleware.ts
  // Here we define any additional redirects at the infra level
  async redirects() {
    return [
      {
        source: "/",
        destination: "/login",
        permanent: false,
      },
    ];
  },

  // Security headers
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Frame-Options", value: "DENY" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          {
            key: "Permissions-Policy",
            value: "camera=(), microphone=(), geolocation=()",
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
