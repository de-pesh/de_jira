# Jira Lite

A focused task management SaaS for teams.

## 🚀 Running Locally (3 commands)

```bash
npm install
npm run setup
npm run dev
```

Then open: **http://localhost:3000**

---

## 🔑 Demo Login Credentials

All accounts use the same password: **`Admin@1234`**

| Email | Role | Access |
|---|---|---|
| super@admin.com | Super Admin | Platform overview, all companies |
| alice@acme.com | Company Admin | Full company control |
| bob@acme.com | Manager | All tasks, assign to anyone |
| carol@acme.com | Staff | Own tasks only |

---

## 📁 Project Structure

```
jira-lite/
├── data/               ← CSV "database" (swap for Postgres later)
├── lib/
│   ├── db/db.ts        ← ONLY file to change when upgrading DB
│   ├── auth/           ← JWT sessions, RBAC, password hashing
│   ├── validation/     ← Zod schemas for all inputs
│   └── email/          ← Email service (logs to console in dev)
├── app/
│   ├── api/            ← All API routes
│   ├── login/          ← Login page
│   ├── dashboard/      ← Company admin dashboard
│   ├── tasks/          ← Task board (Kanban + List)
│   ├── employees/      ← Employee management
│   └── admin/          ← Super admin panel
├── components/
│   ├── ui/             ← Toast, ConfirmDialog
│   ├── layout/         ← Sidebar (responsive)
│   └── skeletons/      ← Loading states & empty states
└── middleware.ts       ← Route protection & role redirects
```

---

## 🔄 Upgrading from CSV to a real database

1. Set up Postgres (e.g. Supabase)
2. Add `DATABASE_URL` to `.env.local`
3. Install Prisma: `npm install prisma @prisma/client`
4. **Only edit `lib/db/db.ts`** — replace CSV reads/writes with Prisma calls
5. Keep all exported function names identical
6. Delete the `data/*.csv` files

No other files need to change.

---

## 🛠 Environment Variables

| Variable | Required | Description |
|---|---|---|
| `JWT_SECRET` | ✅ | Min 32 chars, used to sign session tokens |
| `NEXT_PUBLIC_APP_URL` | ✅ | App URL (http://localhost:3000 in dev) |
| `RESEND_API_KEY` | ❌ | For real emails. Leave blank → logs to terminal |
