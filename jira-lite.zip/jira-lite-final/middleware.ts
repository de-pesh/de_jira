// ============================================================
// middleware.ts  (lives at project root)
// Protects all routes based on role.
// Redirects unauthenticated users to /login.
// Redirects users to their correct dashboard.
// ============================================================

import { NextRequest, NextResponse } from "next/server";
import { verifySession } from "@/lib/auth/session";
import type { UserRole } from "@/lib/db/types";

// ─── Public routes (no auth required) ───────────────────────
const PUBLIC_ROUTES = ["/login", "/reset-password", "/forgot-password"];

// ─── Role → default landing page ────────────────────────────
const ROLE_HOME: Record<UserRole, string> = {
  super_admin: "/admin",
  company_admin: "/dashboard",
  manager: "/tasks",
  staff: "/tasks",
};

// ─── Route prefix → minimum role required ───────────────────
const PROTECTED_ROUTES: Array<{ prefix: string; minRole: UserRole }> = [
  { prefix: "/admin", minRole: "super_admin" },
  { prefix: "/dashboard", minRole: "company_admin" },
  { prefix: "/employees", minRole: "company_admin" },
  { prefix: "/tasks", minRole: "staff" },
  { prefix: "/api/admin", minRole: "super_admin" },
];

const ROLE_HIERARCHY: Record<UserRole, number> = {
  staff: 1,
  manager: 2,
  company_admin: 3,
  super_admin: 4,
};

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Allow public routes
  if (PUBLIC_ROUTES.some((r) => pathname.startsWith(r))) {
    return NextResponse.next();
  }

  // Allow Next.js internals & static files
  if (pathname.startsWith("/_next") || pathname.startsWith("/favicon")) {
    return NextResponse.next();
  }

  // Get session from cookie
  const token = req.cookies.get("jira_lite_session")?.value;
  const session = token ? await verifySession(token) : null;

  // Not logged in → redirect to login
  if (!session) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // Redirect root "/" to role-based home
  if (pathname === "/") {
    return NextResponse.redirect(new URL(ROLE_HOME[session.role], req.url));
  }

  // Check route-level role requirements
  const matchedRoute = PROTECTED_ROUTES.find((r) => pathname.startsWith(r.prefix));
  if (matchedRoute) {
    const userLevel = ROLE_HIERARCHY[session.role];
    const requiredLevel = ROLE_HIERARCHY[matchedRoute.minRole];
    if (userLevel < requiredLevel) {
      // Redirect to their own home instead of 403 page
      return NextResponse.redirect(new URL(ROLE_HOME[session.role], req.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
