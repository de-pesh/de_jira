// ============================================================
// lib/auth/password.ts
// Password hashing and verification using bcryptjs.
// Also handles reset token generation and storage.
// ============================================================

import bcrypt from "bcryptjs";
import crypto from "crypto";
import fs from "fs";
import path from "path";

const SALT_ROUNDS = 12;

// ─── Hash a plain password ───────────────────────────────────
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, SALT_ROUNDS);
}

// ─── Compare plain password against hash ────────────────────
export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

// ─── Reset tokens (stored in a simple JSON file for now) ────
// When upgrading DB: replace with a reset_tokens table.

const TOKEN_FILE = path.join(process.cwd(), "data", "reset_tokens.json");

interface ResetToken {
  token: string;
  userId: string;
  email: string;
  expiresAt: string; // ISO date
  used: boolean;
}

function readTokens(): ResetToken[] {
  if (!fs.existsSync(TOKEN_FILE)) return [];
  return JSON.parse(fs.readFileSync(TOKEN_FILE, "utf-8"));
}

function writeTokens(tokens: ResetToken[]): void {
  fs.writeFileSync(TOKEN_FILE, JSON.stringify(tokens, null, 2), "utf-8");
}

// Generate a secure reset token (valid for 1 hour)
export function generateResetToken(userId: string, email: string): string {
  const token = crypto.randomBytes(32).toString("hex");
  const tokens = readTokens().filter((t) => t.email !== email); // invalidate old tokens for this email

  tokens.push({
    token,
    userId,
    email,
    expiresAt: new Date(Date.now() + 60 * 60 * 1000).toISOString(), // 1 hour
    used: false,
  });

  writeTokens(tokens);
  return token;
}

// Verify a reset token — returns userId if valid, null if invalid/expired
export function verifyResetToken(token: string): { userId: string; email: string } | null {
  const tokens = readTokens();
  const entry = tokens.find((t) => t.token === token);

  if (!entry) return null;
  if (entry.used) return null;
  if (new Date(entry.expiresAt) < new Date()) return null;

  return { userId: entry.userId, email: entry.email };
}

// Mark a token as used after password reset
export function consumeResetToken(token: string): void {
  const tokens = readTokens();
  const index = tokens.findIndex((t) => t.token === token);
  if (index !== -1) {
    tokens[index].used = true;
    writeTokens(tokens);
  }
}
