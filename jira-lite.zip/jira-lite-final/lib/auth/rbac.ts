// ============================================================
// lib/auth/rbac.ts
// Role-Based Access Control.
// Defines what each role can do and provides guard helpers.
// ============================================================

import { NextRequest, NextResponse } from "next/server";
import { getSession, type SessionPayload } from "./session";
import type { UserRole } from "@/lib/db/types";

// ─── Role hierarchy (higher index = more permissions) ───────
export const ROLE_HIERARCHY: Record<UserRole, number> = {
  staff: 1,
  manager: 2,
  company_admin: 3,
  super_admin: 4,
};

// ─── Permission definitions ──────────────────────────────────
export const PERMISSIONS = {
  // Task permissions
  "task:create": ["staff", "manager", "company_admin", "super_admin"],
  "task:read:own": ["staff", "manager", "company_admin", "super_admin"],
  "task:read:all": ["manager", "company_admin", "super_admin"],
  "task:update:own": ["staff", "manager", "company_admin", "super_admin"],
  "task:update:any": ["manager", "company_admin", "super_admin"],
  "task:delete:own": ["manager", "company_admin", "super_admin"],
  "task:delete:any": ["company_admin", "super_admin"],

  // User/employee permissions
  "user:read:own": ["staff", "manager", "company_admin", "super_admin"],
  "user:read:all": ["manager", "company_admin", "super_admin"],
  "user:create": ["company_admin", "super_admin"],
  "user:update:any": ["company_admin", "super_admin"],
  "user:delete": ["company_admin", "super_admin"],
  "user:approve": ["company_admin", "super_admin"],
  "user:reset-password": ["company_admin", "super_admin"],

  // Comment permissions
  "comment:create": ["staff", "manager", "company_admin", "super_admin"],
  "comment:delete:own": ["staff", "manager", "company_admin", "super_admin"],
  "comment:delete:any": ["company_admin", "super_admin"],

  // Admin permissions
  "company:read:own": ["company_admin", "super_admin"],
  "company:read:all": ["super_admin"],
  "analytics:company": ["company_admin", "super_admin"],
  "analytics:platform": ["super_admin"],
} as const;

export type Permission = keyof typeof PERMISSIONS;

// ─── Check if a role has a permission ───────────────────────
export function hasPermission(role: UserRole, permission: Permission): boolean {
  const allowed = PERMISSIONS[permission] as readonly string[];
  return allowed.includes(role);
}

// ─── Check if role meets minimum level ──────────────────────
export function hasMinRole(role: UserRole, minRole: UserRole): boolean {
  return ROLE_HIERARCHY[role] >= ROLE_HIERARCHY[minRole];
}

// ─── API Route guard ─────────────────────────────────────────
// Usage: const { session, error } = await requireAuth(req, "task:create")
export async function requireAuth(
  req: NextRequest,
  permission?: Permission
): Promise<{ session: SessionPayload; error: null } | { session: null; error: NextResponse }> {
  const session = await getSession();

  if (!session) {
    return {
      session: null,
      error: NextResponse.json({ error: "Unauthorized. Please log in." }, { status: 401 }),
    };
  }

  if (permission && !hasPermission(session.role, permission)) {
    return {
      session: null,
      error: NextResponse.json(
        { error: `Forbidden. Your role (${session.role}) cannot perform: ${permission}` },
        { status: 403 }
      ),
    };
  }

  return { session, error: null };
}

// ─── Company isolation guard ─────────────────────────────────
// Ensures a user can only access their own company's data
// (super_admin bypasses this check)
export function requireSameCompany(
  session: SessionPayload,
  resourceCompanyId: string
): NextResponse | null {
  if (session.role === "super_admin") return null; // super admin sees all
  if (session.companyId !== resourceCompanyId) {
    return NextResponse.json({ error: "Forbidden. Resource belongs to another company." }, { status: 403 });
  }
  return null;
}

// ─── Task ownership guard ────────────────────────────────────
// Returns error if user can't modify a task they don't own
export function requireTaskAccess(
  session: SessionPayload,
  task: { createdById: string; assignedToId: string; companyId: string },
  action: "update" | "delete"
): NextResponse | null {
  const companyError = requireSameCompany(session, task.companyId);
  if (companyError) return companyError;

  const isOwner = task.createdById === session.userId || task.assignedToId === session.userId;
  const canAccessAny = hasPermission(session.role, `task:${action}:any`);

  if (!isOwner && !canAccessAny) {
    return NextResponse.json(
      { error: "Forbidden. You can only modify tasks you created or are assigned to." },
      { status: 403 }
    );
  }
  return null;
}
