// ============================================================
// lib/email/mailer.ts
// Email sending abstraction.
// Current: logs to console (dev mode).
// Production: replace sendEmail internals with Resend.
// ============================================================

interface EmailPayload {
  to: string;
  subject: string;
  html: string;
}

// ─── Core send function (swap this for Resend in production) ─
async function sendEmail(payload: EmailPayload): Promise<void> {
  if (process.env.NODE_ENV !== "production") {
    // Dev: just log the email
    console.log("\n📧 [DEV EMAIL]");
    console.log(`To: ${payload.to}`);
    console.log(`Subject: ${payload.subject}`);
    console.log(`Body:\n${payload.html}\n`);
    return;
  }

  // Production: uncomment and use Resend
  // const resend = new Resend(process.env.RESEND_API_KEY);
  // await resend.emails.send({
  //   from: "noreply@yourdomain.com",
  //   to: payload.to,
  //   subject: payload.subject,
  //   html: payload.html,
  // });
}

// ─── Password reset email ─────────────────────────────────────
export async function sendPasswordResetEmail(
  to: string,
  name: string,
  resetToken: string
): Promise<void> {
  const resetUrl = `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/reset-password?token=${resetToken}`;

  await sendEmail({
    to,
    subject: "Reset your Jira Lite password",
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
        <h2>Password Reset Request</h2>
        <p>Hi ${name},</p>
        <p>Someone requested a password reset for your account. Click the button below to set a new password.</p>
        <a href="${resetUrl}" style="
          display: inline-block;
          background: #4f46e5;
          color: white;
          padding: 12px 24px;
          border-radius: 6px;
          text-decoration: none;
          margin: 16px 0;
        ">Reset Password</a>
        <p>This link expires in <strong>1 hour</strong>.</p>
        <p>If you didn't request this, you can safely ignore this email.</p>
        <hr />
        <p style="color: #888; font-size: 12px;">
          Or copy this link: ${resetUrl}
        </p>
      </div>
    `,
  });
}

// ─── Welcome email (sent when admin adds a new employee) ─────
export async function sendWelcomeEmail(
  to: string,
  name: string,
  tempPassword: string
): Promise<void> {
  const loginUrl = `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/login`;

  await sendEmail({
    to,
    subject: "Welcome to Jira Lite — Your account is ready",
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
        <h2>Welcome to Jira Lite, ${name}!</h2>
        <p>Your account has been created. Here are your login details:</p>
        <table style="background: #f4f4f5; padding: 16px; border-radius: 6px; width: 100%;">
          <tr><td><strong>Email:</strong></td><td>${to}</td></tr>
          <tr><td><strong>Temp Password:</strong></td><td>${tempPassword}</td></tr>
        </table>
        <a href="${loginUrl}" style="
          display: inline-block;
          background: #4f46e5;
          color: white;
          padding: 12px 24px;
          border-radius: 6px;
          text-decoration: none;
          margin: 16px 0;
        ">Log In Now</a>
        <p style="color: #888; font-size: 13px;">
          Please change your password after your first login.
        </p>
      </div>
    `,
  });
}

// ─── Task assigned notification ──────────────────────────────
export async function sendTaskAssignedEmail(
  to: string,
  assigneeName: string,
  taskTitle: string,
  assignedByName: string,
  deadline: string
): Promise<void> {
  const tasksUrl = `${process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000"}/tasks`;

  await sendEmail({
    to,
    subject: `New task assigned: ${taskTitle}`,
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
        <h2>You have a new task</h2>
        <p>Hi ${assigneeName},</p>
        <p><strong>${assignedByName}</strong> assigned you a task:</p>
        <div style="background: #f4f4f5; padding: 16px; border-radius: 6px;">
          <strong>${taskTitle}</strong><br />
          <span style="color: #888;">Deadline: ${new Date(deadline).toLocaleDateString()}</span>
        </div>
        <a href="${tasksUrl}" style="
          display: inline-block;
          background: #4f46e5;
          color: white;
          padding: 12px 24px;
          border-radius: 6px;
          text-decoration: none;
          margin: 16px 0;
        ">View Task</a>
      </div>
    `,
  });
}
