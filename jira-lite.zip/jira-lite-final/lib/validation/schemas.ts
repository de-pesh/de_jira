// ============================================================
// lib/validation/schemas.ts
// Zod schemas for all API inputs.
// Used in API routes to validate request bodies.
// ============================================================

import { z } from "zod";

// ─── Reusable field definitions ──────────────────────────────
const id = z.string().uuid("Invalid ID format");
const email = z.string().email("Invalid email address");
const password = z
  .string()
  .min(8, "Password must be at least 8 characters")
  .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
  .regex(/[0-9]/, "Password must contain at least one number");

const isoDate = z.string().datetime({ message: "Invalid date format. Use ISO 8601." });

// ============================================================
// AUTH
// ============================================================

export const LoginSchema = z.object({
  email,
  password: z.string().min(1, "Password is required"),
});

export const ForgotPasswordSchema = z.object({ email });

export const ResetPasswordSchema = z
  .object({
    token: z.string().min(1, "Reset token is required"),
    password,
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export const ChangePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, "Current password is required"),
    newPassword: password,
    confirmPassword: z.string(),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

// ============================================================
// USERS
// ============================================================

export const CreateUserSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(100),
  email,
  password,
  role: z.enum(["manager", "staff"], {
    errorMap: () => ({ message: "Role must be manager or staff" }),
  }),
  companyId: z.string().min(1, "Company ID is required"),
});

export const UpdateUserSchema = z.object({
  name: z.string().min(2).max(100).optional(),
  email: email.optional(),
  role: z.enum(["manager", "staff"]).optional(),
  status: z.enum(["active", "pending", "suspended"]).optional(),
});

export const AdminResetPasswordSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  newPassword: password,
});

// ============================================================
// TASKS
// ============================================================

export const CreateTaskSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters").max(200),
  description: z.string().max(5000).optional().default(""),
  priority: z.enum(["low", "medium", "high", "critical"]),
  deadline: isoDate,
  assignedToId: z.string().min(1, "Assigned user is required"),
});

export const UpdateTaskSchema = z.object({
  title: z.string().min(3).max(200).optional(),
  description: z.string().max(5000).optional(),
  status: z.enum(["todo", "in_progress", "in_review", "done"]).optional(),
  priority: z.enum(["low", "medium", "high", "critical"]).optional(),
  deadline: isoDate.optional(),
  assignedToId: z.string().min(1).optional(),
});

export const TaskFilterSchema = z.object({
  status: z.enum(["todo", "in_progress", "in_review", "done"]).optional(),
  priority: z.enum(["low", "medium", "high", "critical"]).optional(),
  assignedToId: z.string().optional(),
  createdById: z.string().optional(),
  search: z.string().max(200).optional(),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
});

// ============================================================
// COMMENTS
// ============================================================

export const CreateCommentSchema = z.object({
  body: z.string().min(1, "Comment cannot be empty").max(2000),
});

// ─── Type exports ────────────────────────────────────────────
export type LoginInput = z.infer<typeof LoginSchema>;
export type CreateUserInput = z.infer<typeof CreateUserSchema>;
export type UpdateUserInput = z.infer<typeof UpdateUserSchema>;
export type CreateTaskInput = z.infer<typeof CreateTaskSchema>;
export type UpdateTaskInput = z.infer<typeof UpdateTaskSchema>;
export type TaskFilterInput = z.infer<typeof TaskFilterSchema>;
export type CreateCommentInput = z.infer<typeof CreateCommentSchema>;
