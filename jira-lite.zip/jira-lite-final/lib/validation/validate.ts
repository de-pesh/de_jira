// ============================================================
// lib/validation/validate.ts
// Wraps Zod parsing with clean Next.js API error responses.
// ============================================================

import { NextResponse } from "next/server";
import { ZodSchema, ZodError } from "zod";

type ValidationSuccess<T> = { data: T; error: null };
type ValidationFailure = { data: null; error: NextResponse };

export function validate<T>(
  schema: ZodSchema<T>,
  input: unknown
): ValidationSuccess<T> | ValidationFailure {
  const result = schema.safeParse(input);

  if (!result.success) {
    const errors = formatZodErrors(result.error);
    return {
      data: null,
      error: NextResponse.json({ error: "Validation failed", details: errors }, { status: 400 }),
    };
  }

  return { data: result.data, error: null };
}

// Formats Zod errors into a flat { field: message } map
function formatZodErrors(error: ZodError): Record<string, string> {
  return error.errors.reduce(
    (acc, err) => {
      const key = err.path.join(".") || "root";
      acc[key] = err.message;
      return acc;
    },
    {} as Record<string, string>
  );
}

// Parses JSON body from a request safely
export async function parseBody(req: Request): Promise<{ body: unknown; error: NextResponse | null }> {
  try {
    const body = await req.json();
    return { body, error: null };
  } catch {
    return {
      body: null,
      error: NextResponse.json({ error: "Invalid JSON body" }, { status: 400 }),
    };
  }
}
