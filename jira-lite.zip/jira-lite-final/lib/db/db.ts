// ============================================================
// db.ts — THE ONLY FILE TO TOUCH WHEN UPGRADING THE DATABASE
//
// Current implementation: CSV files (via papaparse)
// Future: Replace internals with Prisma/Supabase calls.
// All function signatures stay the same — the rest of the
// app never changes.
// ============================================================

import Papa from "papaparse";
import fs from "fs";
import path from "path";
import { v4 as uuidv4 } from "uuid";
import type {
  Company,
  User,
  Task,
  Comment,
  ActivityLog,
  CreateTaskInput,
  UpdateTaskInput,
  CreateUserInput,
  UpdateUserInput,
  CreateCommentInput,
  CreateActivityInput,
} from "./types";

// ─── File paths ─────────────────────────────────────────────
const DATA_DIR = path.join(process.cwd(), "data");
const FILES = {
  companies: path.join(DATA_DIR, "companies.csv"),
  users: path.join(DATA_DIR, "users.csv"),
  tasks: path.join(DATA_DIR, "tasks.csv"),
  comments: path.join(DATA_DIR, "comments.csv"),
  activity_logs: path.join(DATA_DIR, "activity_logs.csv"),
};

// ─── Generic CSV helpers ────────────────────────────────────

function readCSV<T>(filePath: string): T[] {
  const content = fs.readFileSync(filePath, "utf-8");
  const result = Papa.parse<T>(content, { header: true, skipEmptyLines: true });
  return result.data;
}

function writeCSV<T>(filePath: string, data: T[]): void {
  const csv = Papa.unparse(data);
  fs.writeFileSync(filePath, csv, "utf-8");
}

function now(): string {
  return new Date().toISOString();
}

// ============================================================
// COMPANIES
// ============================================================

export function getCompanies(): Company[] {
  return readCSV<Company>(FILES.companies);
}

export function getCompanyById(id: string): Company | undefined {
  return getCompanies().find((c) => c.id === id);
}

export function updateCompany(id: string, updates: Partial<Company>): Company | null {
  const companies = getCompanies();
  const index = companies.findIndex((c) => c.id === id);
  if (index === -1) return null;
  companies[index] = { ...companies[index], ...updates };
  writeCSV(FILES.companies, companies);
  return companies[index];
}

// ============================================================
// USERS
// ============================================================

export function getUsers(companyId?: string): User[] {
  const users = readCSV<User>(FILES.users);
  return companyId ? users.filter((u) => u.companyId === companyId) : users;
}

export function getUserById(id: string): User | undefined {
  return getUsers().find((u) => u.id === id);
}

export function getUserByEmail(email: string): User | undefined {
  return getUsers().find((u) => u.email === email);
}

export function createUser(input: CreateUserInput): User {
  const users = getUsers();
  const newUser: User = { ...input, id: uuidv4(), createdAt: now() };
  writeCSV(FILES.users, [...users, newUser]);
  return newUser;
}

export function updateUser(id: string, updates: UpdateUserInput): User | null {
  const users = getUsers();
  const index = users.findIndex((u) => u.id === id);
  if (index === -1) return null;
  users[index] = { ...users[index], ...updates };
  writeCSV(FILES.users, users);
  return users[index];
}

export function deleteUser(id: string): boolean {
  const users = getUsers();
  const filtered = users.filter((u) => u.id !== id);
  if (filtered.length === users.length) return false;
  writeCSV(FILES.users, filtered);
  return true;
}

// ============================================================
// TASKS
// ============================================================

export function getTasks(companyId?: string): Task[] {
  const tasks = readCSV<Task>(FILES.tasks);
  return companyId ? tasks.filter((t) => t.companyId === companyId) : tasks;
}

export function getTaskById(id: string): Task | undefined {
  return getTasks().find((t) => t.id === id);
}

export function getTasksByAssignee(userId: string, companyId?: string): Task[] {
  return getTasks(companyId).filter((t) => t.assignedToId === userId);
}

export function getTasksByCreator(userId: string, companyId?: string): Task[] {
  return getTasks(companyId).filter((t) => t.createdById === userId);
}

export function createTask(input: CreateTaskInput): Task {
  const tasks = getTasks();
  const newTask: Task = { ...input, id: uuidv4(), createdAt: now(), updatedAt: now() };
  writeCSV(FILES.tasks, [...tasks, newTask]);
  return newTask;
}

export function updateTask(id: string, updates: UpdateTaskInput): Task | null {
  const tasks = getTasks();
  const index = tasks.findIndex((t) => t.id === id);
  if (index === -1) return null;
  tasks[index] = { ...tasks[index], ...updates, updatedAt: now() };
  writeCSV(FILES.tasks, tasks);
  return tasks[index];
}

export function deleteTask(id: string): boolean {
  const tasks = getTasks();
  const filtered = tasks.filter((t) => t.id !== id);
  if (filtered.length === tasks.length) return false;
  writeCSV(FILES.tasks, filtered);
  return true;
}

// ============================================================
// COMMENTS
// ============================================================

export function getCommentsByTask(taskId: string): Comment[] {
  return readCSV<Comment>(FILES.comments).filter((c) => c.taskId === taskId);
}

export function createComment(input: CreateCommentInput): Comment {
  const comments = readCSV<Comment>(FILES.comments);
  const newComment: Comment = { ...input, id: uuidv4(), createdAt: now() };
  writeCSV(FILES.comments, [...comments, newComment]);
  return newComment;
}

export function deleteComment(id: string): boolean {
  const comments = readCSV<Comment>(FILES.comments);
  const filtered = comments.filter((c) => c.id !== id);
  if (filtered.length === comments.length) return false;
  writeCSV(FILES.comments, filtered);
  return true;
}

// ============================================================
// ACTIVITY LOG
// ============================================================

export function getActivityLogs(companyId: string, limit = 50): ActivityLog[] {
  return readCSV<ActivityLog>(FILES.activity_logs)
    .filter((l) => l.companyId === companyId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, limit);
}

export function getActivityLogsByTask(taskId: string): ActivityLog[] {
  return readCSV<ActivityLog>(FILES.activity_logs)
    .filter((l) => l.taskId === taskId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function createActivityLog(input: CreateActivityInput): ActivityLog {
  const logs = readCSV<ActivityLog>(FILES.activity_logs);
  const newLog: ActivityLog = { ...input, id: uuidv4(), createdAt: now() };
  writeCSV(FILES.activity_logs, [...logs, newLog]);
  return newLog;
}

// ============================================================
// ANALYTICS (Super Admin)
// ============================================================

export function getPlatformStats() {
  const companies = getCompanies();
  const users = getUsers();
  const tasks = getTasks();

  return {
    totalCompanies: companies.length,
    activeCompanies: companies.filter((c) => c.paymentStatus === "active").length,
    totalUsers: users.length,
    totalTasks: tasks.length,
    tasksByStatus: {
      todo: tasks.filter((t) => t.status === "todo").length,
      in_progress: tasks.filter((t) => t.status === "in_progress").length,
      in_review: tasks.filter((t) => t.status === "in_review").length,
      done: tasks.filter((t) => t.status === "done").length,
    },
    companiesWithPaymentIssues: companies
      .filter((c) => c.paymentStatus === "past_due" || c.paymentStatus === "cancelled")
      .map((c) => ({ id: c.id, name: c.name, status: c.paymentStatus })),
  };
}

export function getCompanyStats(companyId: string) {
  const users = getUsers(companyId);
  const tasks = getTasks(companyId);
  const logs = getActivityLogs(companyId, 100);

  return {
    totalEmployees: users.filter((u) => u.role !== "super_admin").length,
    pendingApprovals: users.filter((u) => u.status === "pending").length,
    totalTasks: tasks.length,
    tasksByStatus: {
      todo: tasks.filter((t) => t.status === "todo").length,
      in_progress: tasks.filter((t) => t.status === "in_progress").length,
      in_review: tasks.filter((t) => t.status === "in_review").length,
      done: tasks.filter((t) => t.status === "done").length,
    },
    tasksByPriority: {
      critical: tasks.filter((t) => t.priority === "critical").length,
      high: tasks.filter((t) => t.priority === "high").length,
      medium: tasks.filter((t) => t.priority === "medium").length,
      low: tasks.filter((t) => t.priority === "low").length,
    },
    overdueTasks: tasks.filter(
      (t) => t.status !== "done" && new Date(t.deadline) < new Date()
    ).length,
    recentActivity: logs.slice(0, 10),
  };
}
