// ============================================================
// types.ts — All shared types for the app
// When upgrading DB: these types stay the same.
// ============================================================

export type UserRole = "super_admin" | "company_admin" | "manager" | "staff";
export type UserStatus = "active" | "pending" | "suspended";

export type TaskStatus = "todo" | "in_progress" | "in_review" | "done";
export type TaskPriority = "low" | "medium" | "high" | "critical";

export type PaymentStatus = "active" | "trial" | "past_due" | "cancelled";

// ─── Company ────────────────────────────────────────────────
export interface Company {
  id: string;
  name: string;
  plan: string;
  paymentStatus: PaymentStatus;
  createdAt: string; // ISO date string
}

// ─── User ───────────────────────────────────────────────────
export interface User {
  id: string;
  companyId: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  passwordHash: string; // placeholder until real auth
  createdAt: string;
}

// ─── Task ───────────────────────────────────────────────────
export interface Task {
  id: string;
  companyId: string;
  title: string;
  description: string;
  status: TaskStatus;
  priority: TaskPriority;
  deadline: string; // ISO date string
  createdById: string;  // user id
  assignedToId: string; // user id
  createdAt: string;
  updatedAt: string;
}

// ─── Comment ────────────────────────────────────────────────
export interface Comment {
  id: string;
  taskId: string;
  userId: string;
  body: string;
  createdAt: string;
}

// ─── Activity Log ───────────────────────────────────────────
export type ActivityAction =
  | "task_created"
  | "task_updated"
  | "task_deleted"
  | "status_changed"
  | "priority_changed"
  | "assigned"
  | "comment_added"
  | "user_added"
  | "user_removed"
  | "user_approved";

export interface ActivityLog {
  id: string;
  companyId: string;
  taskId?: string;
  userId: string;   // who did the action
  action: ActivityAction;
  detail: string;   // human-readable description e.g. "Status changed to Done"
  createdAt: string;
}

// ─── Input types (used for create/update operations) ────────
export type CreateTaskInput = Omit<Task, "id" | "createdAt" | "updatedAt">;
export type UpdateTaskInput = Partial<Omit<Task, "id" | "companyId" | "createdAt">>;

export type CreateUserInput = Omit<User, "id" | "createdAt">;
export type UpdateUserInput = Partial<Omit<User, "id" | "companyId" | "createdAt">>;

export type CreateCommentInput = Omit<Comment, "id" | "createdAt">;
export type CreateActivityInput = Omit<ActivityLog, "id" | "createdAt">;
