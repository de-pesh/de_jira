# 🗄️ Database Layer

## How it works

All data lives in `/data/*.csv` files.
All database access goes through `/lib/db/db.ts`.

```
/data
  companies.csv       ← company + payment info
  users.csv           ← all users across roles
  tasks.csv           ← all tasks
  comments.csv        ← task comments
  activity_logs.csv   ← audit trail

/lib/db
  db.ts               ← ✅ ONLY FILE TO CHANGE when upgrading DB
  types.ts            ← TypeScript types (keep these, they don't change)
```

## Rules

- **Never** import from `data/*.csv` directly in your components or API routes
- **Always** import functions from `lib/db/db.ts`
- The rest of the app calls clean functions like:

```ts
import { getTasks, createTask, updateUser } from "@/lib/db/db";

const tasks = getTasks("company_1");
const task  = createTask({ title: "Fix bug", ... });
```

## Upgrading to Prisma / Supabase later

1. Keep `types.ts` as-is
2. Replace the internals of `db.ts` with Prisma/Supabase calls
3. Keep all exported function names and signatures identical
4. Delete the CSV files
5. Done — zero changes needed in the rest of the app ✅

## Available functions

### Companies
- `getCompanies()`
- `getCompanyById(id)`
- `updateCompany(id, updates)`

### Users
- `getUsers(companyId?)`
- `getUserById(id)`
- `getUserByEmail(email)`
- `createUser(input)`
- `updateUser(id, updates)`
- `deleteUser(id)`

### Tasks
- `getTasks(companyId?)`
- `getTaskById(id)`
- `getTasksByAssignee(userId, companyId?)`
- `getTasksByCreator(userId, companyId?)`
- `createTask(input)`
- `updateTask(id, updates)`
- `deleteTask(id)`

### Comments
- `getCommentsByTask(taskId)`
- `createComment(input)`
- `deleteComment(id)`

### Activity Logs
- `getActivityLogs(companyId, limit?)`
- `getActivityLogsByTask(taskId)`
- `createActivityLog(input)`

### Analytics
- `getPlatformStats()` ← Super Admin
- `getCompanyStats(companyId)` ← Company Admin
