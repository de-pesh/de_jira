// scripts/setup.js
// Run once after npm install:  node scripts/setup.js
// This hashes the default password and writes it into data/users.csv

const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');

const DEFAULT_PASSWORD = 'Admin@1234';
const USERS_CSV = path.join(__dirname, '../data/users.csv');

async function main() {
  console.log('\n🔧 Jira Lite — First-time setup\n');
  console.log(`Hashing default password: ${DEFAULT_PASSWORD}`);

  const hash = await bcrypt.hash(DEFAULT_PASSWORD, 10);
  console.log('✓ Hash generated\n');

  let csv = fs.readFileSync(USERS_CSV, 'utf-8');

  // Replace any placeholder or old hash on every data row
  const lines = csv.split('\n');
  const header = lines[0];
  const rows = lines.slice(1).map(line => {
    if (!line.trim()) return line;
    const cols = line.split(',');
    // passwordHash is column index 6 (0-based)
    cols[6] = hash;
    return cols.join(',');
  });

  fs.writeFileSync(USERS_CSV, [header, ...rows].join('\n'), 'utf-8');
  console.log('✓ data/users.csv updated with hashed passwords\n');

  console.log('─────────────────────────────────────────');
  console.log('  All users have the same password for dev:');
  console.log(`  Password: ${DEFAULT_PASSWORD}`);
  console.log('─────────────────────────────────────────');
  console.log('\n  Demo accounts:');
  console.log('  super@admin.com    → Super Admin');
  console.log('  alice@acme.com     → Company Admin');
  console.log('  bob@acme.com       → Manager');
  console.log('  carol@acme.com     → Staff');
  console.log('\n✅ Setup complete. Run: npm run dev\n');
}

main().catch(console.error);
