"use client";
// components/layout/Sidebar.tsx
// Responsive sidebar:
//   - Desktop: always visible, fixed left
//   - Mobile: hidden by default, slides in via hamburger toggle

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { SessionPayload } from "@/lib/auth/session";

interface NavItem {
  label: string;
  href: string;
  badge?: number;
  icon: React.ReactNode;
  minRole?: SessionPayload["role"][];
}

const ROLE_HIERARCHY: Record<string, number> = {
  staff: 1, manager: 2, company_admin: 3, super_admin: 4,
};

const NAV_ITEMS: NavItem[] = [
  {
    label: "Overview",
    href: "/admin",
    minRole: ["super_admin"],
    icon: <GridIcon />,
  },
  {
    label: "Dashboard",
    href: "/dashboard",
    minRole: ["company_admin", "super_admin"],
    icon: <GridIcon />,
  },
  {
    label: "Tasks",
    href: "/tasks",
    minRole: ["staff", "manager", "company_admin", "super_admin"],
    icon: <ListIcon />,
  },
  {
    label: "Employees",
    href: "/employees",
    minRole: ["company_admin", "super_admin"],
    icon: <UsersIcon />,
  },
  {
    label: "Analytics",
    href: "/analytics",
    minRole: ["company_admin", "super_admin"],
    icon: <ChartIcon />,
  },
  {
    label: "Activity Log",
    href: "/activity",
    minRole: ["company_admin", "super_admin"],
    icon: <LogIcon />,
  },
];

interface SidebarProps {
  session: SessionPayload;
  pendingCount?: number;
}

export function Sidebar({ session, pendingCount = 0 }: SidebarProps) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);

  // Close on route change
  useEffect(() => setMobileOpen(false), [pathname]);

  // Lock body scroll when mobile sidebar is open
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  const visibleItems = NAV_ITEMS.filter(item =>
    !item.minRole || item.minRole.includes(session.role)
  );

  const userInitials = session.name
    .split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2);

  const sidebarContent = (
    <aside style={{
      background: "var(--blue-900)",
      display: "flex", flexDirection: "column",
      height: "100%", width: "220px",
    }}>
      {/* Logo */}
      <div style={{
        padding: "20px 18px 16px",
        display: "flex", alignItems: "center", gap: "10px",
        borderBottom: "1px solid rgba(255,255,255,0.08)",
      }}>
        <div style={{
          width: 28, height: 28, background: "var(--blue-500)",
          borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center",
          flexShrink: 0,
        }}>
          <LogoIcon />
        </div>
        <span style={{ fontSize: 14, fontWeight: 600, color: "white", letterSpacing: "-0.02em" }}>
          Jira Lite
        </span>
        {session.role === "super_admin" && (
          <span style={{
            fontSize: 9, fontWeight: 600, background: "rgba(59,130,246,0.2)",
            color: "var(--blue-200)", border: "1px solid rgba(59,130,246,0.3)",
            borderRadius: 4, padding: "1px 5px", letterSpacing: "0.06em",
            textTransform: "uppercase",
          }}>Root</span>
        )}
      </div>

      {/* Nav */}
      <nav style={{ padding: "12px 10px", flex: 1, overflowY: "auto" }}>
        {visibleItems.map(item => {
          const active = pathname === item.href || pathname.startsWith(item.href + "/");
          const badge = item.label === "Employees" ? pendingCount : undefined;
          return (
            <Link
              key={item.href}
              href={item.href}
              style={{
                display: "flex", alignItems: "center", gap: 9,
                padding: "8px 8px", borderRadius: 6,
                fontSize: 13, textDecoration: "none",
                marginBottom: 2,
                color: active ? "white" : "rgba(255,255,255,0.5)",
                background: active ? "rgba(59,130,246,0.2)" : "transparent",
                fontWeight: active ? 500 : 400,
                border: active ? "1px solid rgba(59,130,246,0.2)" : "1px solid transparent",
                transition: "all 0.15s",
              }}
            >
              {item.icon}
              <span style={{ flex: 1 }}>{item.label}</span>
              {badge ? (
                <span style={{
                  background: "#dc2626", color: "white",
                  fontSize: 10, fontWeight: 600, borderRadius: 10,
                  padding: "0 6px", fontFamily: "var(--font-dm-mono)",
                }}>{badge}</span>
              ) : null}
            </Link>
          );
        })}
      </nav>

      {/* User footer */}
      <div style={{
        padding: "12px 14px",
        borderTop: "1px solid rgba(255,255,255,0.08)",
        display: "flex", alignItems: "center", gap: 9,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: "50%",
          background: "linear-gradient(135deg,#1d4ed8,#3b82f6)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 11, fontWeight: 700, color: "white", flexShrink: 0,
        }}>{userInitials}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12.5, fontWeight: 500, color: "rgba(255,255,255,0.75)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {session.name}
          </div>
          <div style={{ fontSize: 10.5, color: "rgba(255,255,255,0.35)" }}>
            {session.role.replace("_", " ")}
          </div>
        </div>
        <form action="/api/auth/logout" method="POST">
          <button type="submit" title="Sign out" style={{
            background: "none", border: "none", cursor: "pointer",
            color: "rgba(255,255,255,0.25)", padding: 4, borderRadius: 4,
            display: "flex", transition: "color 0.15s",
          }}>
            <LogoutIcon />
          </button>
        </form>
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop: sticky sidebar */}
      <div className="sidebar-desktop" style={{
        position: "sticky", top: 0, height: "100vh",
        display: "none", // shown via CSS below
      }}>
        {sidebarContent}
      </div>

      {/* Mobile: hamburger button */}
      <button
        className="sidebar-hamburger"
        onClick={() => setMobileOpen(true)}
        aria-label="Open menu"
        style={{
          position: "fixed", top: 14, left: 16, zIndex: 110,
          background: "var(--blue-900)", border: "none",
          borderRadius: 8, padding: "8px", cursor: "pointer",
          display: "none", // shown via CSS below
          color: "white", alignItems: "center", justifyContent: "center",
          boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
        }}
      >
        <HamburgerIcon />
      </button>

      {/* Mobile: overlay + drawer */}
      {mobileOpen && (
        <>
          <div
            onClick={() => setMobileOpen(false)}
            style={{
              position: "fixed", inset: 0, background: "rgba(0,0,0,0.5)",
              zIndex: 120, backdropFilter: "blur(2px)",
            }}
          />
          <div style={{
            position: "fixed", top: 0, left: 0, bottom: 0,
            zIndex: 130, animation: "slideInLeft 0.25s",
          }}>
            {sidebarContent}
            {/* Close button */}
            <button
              onClick={() => setMobileOpen(false)}
              style={{
                position: "absolute", top: 14, right: -40,
                background: "rgba(0,0,0,0.5)", border: "none",
                borderRadius: "0 6px 6px 0", padding: "10px 10px",
                cursor: "pointer", color: "white", display: "flex",
              }}
            >
              ✕
            </button>
          </div>
        </>
      )}

      <style>{`
        @media (min-width: 769px) {
          .sidebar-desktop { display: block !important; }
          .sidebar-hamburger { display: none !important; }
        }
        @media (max-width: 768px) {
          .sidebar-desktop { display: none !important; }
          .sidebar-hamburger { display: flex !important; }
        }
        @keyframes slideInLeft {
          from { transform: translateX(-100%) }
          to   { transform: translateX(0) }
        }
      `}</style>
    </>
  );
}

// ── Icons ─────────────────────────────────────────────────────
function GridIcon() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><rect x="1" y="1" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/><rect x="8" y="1" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/><rect x="1" y="8" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/><rect x="8" y="8" width="5" height="5" rx="1" stroke="currentColor" strokeWidth="1.4"/></svg>;
}
function ListIcon() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 4h10M2 7h7M2 10h5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg>;
}
function UsersIcon() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="5" cy="4.5" r="2" stroke="currentColor" strokeWidth="1.4"/><path d="M1 11.5c0-2.21 1.79-3 4-3s4 .79 4 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><path d="M9.5 6.5l1 1 2-2" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
function ChartIcon() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1 11l3-4 3 2.5 3.5-5L13 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
function LogIcon() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 11V5l5-3 5 3v6l-5 2-5-2z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round"/></svg>;
}
function LogoIcon() {
  return <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="6" height="6" rx="1.5" fill="white" opacity="0.9"/><rect x="9" y="1" width="6" height="6" rx="1.5" fill="white" opacity="0.5"/><rect x="1" y="9" width="6" height="6" rx="1.5" fill="white" opacity="0.5"/><rect x="9" y="9" width="6" height="6" rx="1.5" fill="white" opacity="0.25"/></svg>;
}
function LogoutIcon() {
  return <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M5 2H2.5A1.5 1.5 0 001 3.5v7A1.5 1.5 0 002.5 12H5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/><path d="M9 9.5l2.5-2.5L9 4.5M11.5 7H5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/></svg>;
}
function HamburgerIcon() {
  return <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M2 4.5h14M2 9h14M2 13.5h14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"/></svg>;
}
