// components/skeletons/Skeletons.tsx
// Skeleton loaders for every major view.
// Usage: import { TaskBoardSkeleton } from "@/components/skeletons/Skeletons"

import React from "react";

// ─── Base pulse block ─────────────────────────────────────────
function Bone({
  w = "100%", h = 14, r = 6, style = {},
}: { w?: string | number; h?: number; r?: number; style?: React.CSSProperties }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: r,
      background: "linear-gradient(90deg,#e2e8f0 25%,#f1f5f9 50%,#e2e8f0 75%)",
      backgroundSize: "200% 100%",
      animation: "shimmer 1.5s infinite",
      flexShrink: 0,
      ...style,
    }} />
  );
}

const SHIMMER = `@keyframes shimmer { from { background-position: 200% 0 } to { background-position: -200% 0 } }`;

// ─── Stat card skeleton ───────────────────────────────────────
function StatCardSkeleton() {
  return (
    <div style={{
      background: "#fff", border: "1px solid #e2e8f0",
      borderRadius: 12, padding: "18px 20px",
      display: "flex", flexDirection: "column", gap: 10,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Bone w={34} h={34} r={9} />
        <Bone w={60} h={20} r={10} />
      </div>
      <Bone w={50} h={28} r={6} />
      <Bone w="70%" h={12} r={4} />
    </div>
  );
}

// ─── Dashboard skeleton ───────────────────────────────────────
export function DashboardSkeleton() {
  return (
    <div style={{ padding: "24px 28px" }}>
      <style>{SHIMMER}</style>

      {/* Greeting */}
      <div style={{ marginBottom: 22 }}>
        <Bone w={200} h={24} r={6} style={{ marginBottom: 8 }} />
        <Bone w={280} h={14} r={4} />
      </div>

      {/* Stats row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 22 }}>
        {[...Array(4)].map((_, i) => <StatCardSkeleton key={i} />)}
      </div>

      {/* Two col */}
      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 16 }}>
        <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: 18, display: "flex", flexDirection: "column", gap: 14 }}>
          <Bone w={120} h={16} />
          {[...Array(5)].map((_, i) => (
            <div key={i} style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <Bone w={3} h={32} r={2} />
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 5 }}>
                <Bone w="60%" h={13} />
                <Bone w="40%" h={11} />
              </div>
              <Bone w={70} h={22} r={10} />
            </div>
          ))}
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: 18 }}>
            <Bone w={120} h={14} style={{ marginBottom: 14 }} />
            {[...Array(2)].map((_, i) => (
              <div key={i} style={{ display: "flex", gap: 10, marginBottom: 12, alignItems: "center" }}>
                <Bone w={32} h={32} r={50} />
                <div style={{ flex: 1 }}><Bone w="70%" h={12} style={{ marginBottom: 5 }} /><Bone w="50%" h={10} /></div>
              </div>
            ))}
          </div>
          <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 12, padding: 18 }}>
            <Bone w={120} h={14} style={{ marginBottom: 14 }} />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1 }}>
              {[...Array(4)].map((_, i) => (
                <div key={i} style={{ padding: "12px 14px", textAlign: "center" }}>
                  <Bone w={30} h={22} r={4} style={{ margin: "0 auto 6px" }} />
                  <Bone w="60%" h={10} r={3} style={{ margin: "0 auto" }} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Task board skeleton ──────────────────────────────────────
export function TaskBoardSkeleton() {
  return (
    <div style={{ padding: "18px 24px", display: "flex", gap: 14 }}>
      <style>{SHIMMER}</style>
      {["Todo", "In Progress", "In Review", "Done"].map((col, ci) => (
        <div key={col} style={{ width: 270, flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
            <Bone w={8} h={8} r={50} />
            <Bone w={80} h={13} />
            <Bone w={24} h={18} r={9} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {[...Array(ci === 0 ? 2 : ci === 3 ? 1 : 1)].map((_, i) => (
              <div key={i} style={{
                background: "#fff", border: "1px solid #e2e8f0",
                borderRadius: 10, padding: "13px 14px",
              }}>
                <Bone w="80%" h={13} style={{ marginBottom: 8 }} />
                <Bone w="100%" h={10} style={{ marginBottom: 4 }} />
                <Bone w="70%" h={10} style={{ marginBottom: 12 }} />
                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <Bone w={60} h={20} r={6} />
                  <Bone w={22} h={22} r={50} />
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Employee table skeleton ──────────────────────────────────
export function EmployeeTableSkeleton() {
  return (
    <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: "0 0 12px 12px" }}>
      <style>{SHIMMER}</style>
      {/* toolbar */}
      <div style={{ padding: "12px 18px", borderBottom: "1px solid #e2e8f0", display: "flex", gap: 10 }}>
        <Bone w={220} h={36} r={7} />
        <Bone w={120} h={36} r={7} />
      </div>
      {/* header */}
      <div style={{ padding: "10px 18px", display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr 1fr", gap: 12, borderBottom: "1px solid #e2e8f0" }}>
        {[...Array(6)].map((_, i) => <Bone key={i} w="70%" h={11} />)}
      </div>
      {/* rows */}
      {[...Array(5)].map((_, i) => (
        <div key={i} style={{ padding: "13px 18px", display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr 1fr", gap: 12, alignItems: "center", borderBottom: "1px solid #e2e8f0" }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <Bone w={34} h={34} r={50} />
            <div><Bone w={100} h={13} style={{ marginBottom: 5 }} /><Bone w={130} h={11} /></div>
          </div>
          <Bone w={70} h={22} r={10} />
          <Bone w={60} h={20} r={10} />
          <Bone w={30} h={13} />
          <Bone w={80} h={13} />
          <div style={{ display: "flex", gap: 6 }}><Bone w={28} h={28} r={6} /><Bone w={28} h={28} r={6} /></div>
        </div>
      ))}
    </div>
  );
}

// ─── Task detail skeleton ─────────────────────────────────────
export function TaskDetailSkeleton() {
  return (
    <div style={{ padding: 24, display: "grid", gridTemplateColumns: "1fr 300px", gap: 20 }}>
      <style>{SHIMMER}</style>

      {/* left */}
      <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: 24 }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          <Bone w={70} h={24} r={6} />
          <Bone w={90} h={24} r={6} />
          <Bone w={70} h={24} r={6} />
        </div>
        <Bone w="75%" h={28} r={6} style={{ marginBottom: 16 }} />
        <Bone w="100%" h={13} style={{ marginBottom: 6 }} />
        <Bone w="100%" h={13} style={{ marginBottom: 6 }} />
        <Bone w="80%" h={13} style={{ marginBottom: 32 }} />

        <Bone w={100} h={16} style={{ marginBottom: 20 }} />
        {[...Array(2)].map((_, i) => (
          <div key={i} style={{ display: "flex", gap: 10, marginBottom: 18 }}>
            <Bone w={30} h={30} r={50} />
            <div style={{ flex: 1 }}>
              <Bone w={140} h={13} style={{ marginBottom: 8 }} />
              <Bone w="100%" h={60} r={8} />
            </div>
          </div>
        ))}
      </div>

      {/* right */}
      <div style={{ background: "#fff", border: "1px solid #e2e8f0", borderRadius: 14, padding: 18 }}>
        <Bone w={60} h={11} style={{ marginBottom: 14 }} />
        {[...Array(4)].map((_, i) => (
          <div key={i} style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 12 }}>
            <Bone w={70} h={12} />
            <Bone w={110} h={12} />
          </div>
        ))}
        <div style={{ height: 1, background: "#e2e8f0", margin: "16px 0" }} />
        <Bone w={60} h={11} style={{ marginBottom: 14 }} />
        {[...Array(3)].map((_, i) => (
          <div key={i} style={{ display: "flex", gap: 10, marginBottom: 12 }}>
            <Bone w={8} h={8} r={50} style={{ marginTop: 5 }} />
            <div style={{ flex: 1 }}><Bone w="80%" h={12} style={{ marginBottom: 4 }} /><Bone w={60} h={10} /></div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Empty states ─────────────────────────────────────────────
interface EmptyStateProps {
  icon: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <div style={{
      display: "flex", flexDirection: "column", alignItems: "center",
      justifyContent: "center", padding: "60px 24px", textAlign: "center",
    }}>
      <div style={{ fontSize: 36, marginBottom: 14 }}>{icon}</div>
      <div style={{ fontSize: 15, fontWeight: 600, color: "#0f172a", marginBottom: 6 }}>{title}</div>
      {description && (
        <div style={{ fontSize: 13, color: "#64748b", maxWidth: 320, lineHeight: 1.6, marginBottom: 20 }}>
          {description}
        </div>
      )}
      {action}
    </div>
  );
}

// Pre-built empty states for common scenarios
export const EMPTY_STATES = {
  noTasks: (
    <EmptyState
      icon="📋"
      title="No tasks yet"
      description="Create your first task to get the team moving."
    />
  ),
  noEmployees: (
    <EmptyState
      icon="👥"
      title="No employees yet"
      description="Add your first team member to get started."
    />
  ),
  noPending: (
    <EmptyState
      icon="✅"
      title="All caught up"
      description="No pending approvals right now."
    />
  ),
  noResults: (
    <EmptyState
      icon="🔍"
      title="No results found"
      description="Try adjusting your search or filters."
    />
  ),
};
