"use client";
// components/ui/ConfirmDialog.tsx
// Usage:
//   <ConfirmDialog
//     open={open}
//     title="Remove employee?"
//     description="This will revoke their access immediately."
//     confirmLabel="Remove"
//     variant="danger"
//     onConfirm={handleRemove}
//     onCancel={() => setOpen(false)}
//   />

import React, { useEffect } from "react";

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: "danger" | "warning" | "default";
  loading?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

const VARIANT_STYLES = {
  danger:  { btn: "#dc2626", bg: "#fef2f2", icon: "🗑", iconBg: "#fecaca" },
  warning: { btn: "#d97706", bg: "#fffbeb", icon: "⚠",  iconBg: "#fde68a" },
  default: { btn: "#2563eb", bg: "#eff6ff", icon: "?",  iconBg: "#bfdbfe" },
};

export function ConfirmDialog({
  open, title, description,
  confirmLabel = "Confirm", cancelLabel = "Cancel",
  variant = "default", loading = false,
  onConfirm, onCancel,
}: ConfirmDialogProps) {
  const v = VARIANT_STYLES[variant];

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onCancel(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onCancel]);

  if (!open) return null;

  return (
    <div
      onClick={(e) => { if (e.target === e.currentTarget) onCancel(); }}
      style={{
        position: "fixed", inset: 0, background: "rgba(15,23,42,0.45)",
        backdropFilter: "blur(3px)", display: "flex",
        alignItems: "center", justifyContent: "center", zIndex: 200,
        animation: "fadeIn 0.15s",
      }}
    >
      <div style={{
        background: "#fff", borderRadius: "14px", width: "380px",
        maxWidth: "92vw", boxShadow: "0 24px 64px rgba(0,0,0,0.15)",
        overflow: "hidden", animation: "slideUp 0.2s",
      }}>
        {/* Body */}
        <div style={{ padding: "28px 24px 20px", textAlign: "center" }}>
          <div style={{
            width: "48px", height: "48px", borderRadius: "50%",
            background: v.iconBg, fontSize: "20px",
            display: "flex", alignItems: "center", justifyContent: "center",
            margin: "0 auto 14px",
          }}>
            {v.icon}
          </div>
          <div style={{ fontSize: "15px", fontWeight: 600, color: "#0f172a", marginBottom: "8px" }}>
            {title}
          </div>
          {description && (
            <div style={{ fontSize: "13px", color: "#64748b", lineHeight: 1.6 }}>
              {description}
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{
          display: "flex", gap: "8px", padding: "14px 20px",
          borderTop: "1px solid #e2e8f0", justifyContent: "flex-end",
        }}>
          <button
            onClick={onCancel}
            disabled={loading}
            style={{
              fontFamily: "var(--font-dm-sans, sans-serif)",
              fontSize: "13px", fontWeight: 500, padding: "7px 16px",
              borderRadius: "7px", cursor: "pointer",
              border: "1px solid #e2e8f0", background: "none", color: "#64748b",
              transition: "all 0.15s",
            }}
          >
            {cancelLabel}
          </button>
          <button
            onClick={onConfirm}
            disabled={loading}
            style={{
              fontFamily: "var(--font-dm-sans, sans-serif)",
              fontSize: "13px", fontWeight: 500, padding: "7px 16px",
              borderRadius: "7px", cursor: loading ? "not-allowed" : "pointer",
              border: "none", background: v.btn, color: "#fff",
              opacity: loading ? 0.7 : 1, transition: "all 0.15s",
              minWidth: "90px",
            }}
          >
            {loading ? "Please wait…" : confirmLabel}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn { from { opacity: 0 } to { opacity: 1 } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(12px) } to { opacity: 1; transform: translateY(0) } }
      `}</style>
    </div>
  );
}
