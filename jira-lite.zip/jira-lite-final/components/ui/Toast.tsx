"use client";
// components/ui/Toast.tsx
// Usage anywhere in the app:
//   const { toast } = useToast()
//   toast.success("Task created!")
//   toast.error("Something went wrong")
//   toast.warning("Deadline is today")
//   toast.info("Assigned to Bob")

import React, {
  createContext, useContext, useState, useCallback, useEffect, useRef
} from "react";

// ─── Types ───────────────────────────────────────────────────
type ToastType = "success" | "error" | "warning" | "info";

interface Toast {
  id: string;
  type: ToastType;
  title: string;
  message?: string;
  duration?: number; // ms, default 4000
}

interface ToastContextValue {
  toast: {
    success: (title: string, message?: string) => void;
    error:   (title: string, message?: string) => void;
    warning: (title: string, message?: string) => void;
    info:    (title: string, message?: string) => void;
  };
}

// ─── Context ─────────────────────────────────────────────────
const ToastContext = createContext<ToastContextValue | null>(null);

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error("useToast must be used inside <ToastProvider>");
  return ctx;
}

// ─── Provider ────────────────────────────────────────────────
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const add = useCallback((type: ToastType, title: string, message?: string, duration = 4000) => {
    const id = Math.random().toString(36).slice(2);
    setToasts(prev => [...prev, { id, type, title, message, duration }]);
  }, []);

  const remove = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const toast = {
    success: (title: string, msg?: string) => add("success", title, msg),
    error:   (title: string, msg?: string) => add("error",   title, msg),
    warning: (title: string, msg?: string) => add("warning", title, msg),
    info:    (title: string, msg?: string) => add("info",    title, msg),
  };

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <ToastContainer toasts={toasts} onRemove={remove} />
    </ToastContext.Provider>
  );
}

// ─── Container ───────────────────────────────────────────────
function ToastContainer({ toasts, onRemove }: { toasts: Toast[]; onRemove: (id: string) => void }) {
  return (
    <div style={{
      position: "fixed", bottom: "24px", right: "24px",
      display: "flex", flexDirection: "column", gap: "10px",
      zIndex: 9999, pointerEvents: "none",
    }}>
      {toasts.map(t => (
        <ToastItem key={t.id} toast={t} onRemove={onRemove} />
      ))}
    </div>
  );
}

// ─── Individual toast ────────────────────────────────────────
const CONFIG: Record<ToastType, { bg: string; border: string; icon: string; color: string }> = {
  success: { bg: "#f0fdf4", border: "#bbf7d0", color: "#15803d", icon: "✓" },
  error:   { bg: "#fef2f2", border: "#fecaca", color: "#dc2626", icon: "✕" },
  warning: { bg: "#fffbeb", border: "#fde68a", color: "#d97706", icon: "⚠" },
  info:    { bg: "#eff6ff", border: "#bfdbfe", color: "#2563eb", icon: "i" },
};

function ToastItem({ toast, onRemove }: { toast: Toast; onRemove: (id: string) => void }) {
  const [visible, setVisible] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout>>();
  const cfg = CONFIG[toast.type];

  useEffect(() => {
    // Mount → animate in
    requestAnimationFrame(() => setVisible(true));

    // Auto-dismiss
    timerRef.current = setTimeout(() => dismiss(), toast.duration ?? 4000);
    return () => clearTimeout(timerRef.current);
  }, []);

  const dismiss = () => {
    setVisible(false);
    setTimeout(() => onRemove(toast.id), 300);
  };

  return (
    <div
      onClick={dismiss}
      style={{
        pointerEvents: "all",
        display: "flex",
        alignItems: "flex-start",
        gap: "10px",
        padding: "12px 14px",
        background: cfg.bg,
        border: `1px solid ${cfg.border}`,
        borderRadius: "10px",
        minWidth: "280px",
        maxWidth: "360px",
        boxShadow: "0 4px 16px rgba(0,0,0,0.08)",
        cursor: "pointer",
        transition: "opacity 0.3s, transform 0.3s",
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(12px)",
      }}
    >
      {/* Icon */}
      <div style={{
        width: "20px", height: "20px", borderRadius: "50%",
        background: cfg.color, color: "#fff",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: "11px", fontWeight: "700", flexShrink: 0, marginTop: "1px",
      }}>
        {cfg.icon}
      </div>

      {/* Text */}
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: "13px", fontWeight: "600", color: "#0f172a", lineHeight: 1.3 }}>
          {toast.title}
        </div>
        {toast.message && (
          <div style={{ fontSize: "12px", color: "#64748b", marginTop: "3px", lineHeight: 1.4 }}>
            {toast.message}
          </div>
        )}
      </div>

      {/* Close */}
      <div style={{ color: "#94a3b8", fontSize: "14px", flexShrink: 0 }}>×</div>
    </div>
  );
}
