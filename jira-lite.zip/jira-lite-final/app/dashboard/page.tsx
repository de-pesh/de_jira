// app/dashboard/page.tsx
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { getCompanyStats, getUsers } from "@/lib/db/db";
import { Sidebar } from "@/components/layout/Sidebar";

export const metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role === "staff" || session.role === "manager") redirect("/tasks");

  const stats = getCompanyStats(session.companyId);
  const users = getUsers(session.companyId);
  const pendingCount = users.filter(u => u.status === "pending").length;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", minHeight: "100vh" }}>
      <Sidebar session={session} pendingCount={pendingCount} />
      <main>
        {/* Replace with <DashboardClient stats={stats} session={session} /> */}
        <pre style={{ padding: 24, fontSize: 12, color: "#64748b" }}>
          Dashboard for {session.name} — {stats.totalTasks} tasks, {stats.pendingApprovals} pending approvals
        </pre>
      </main>
    </div>
  );
}
