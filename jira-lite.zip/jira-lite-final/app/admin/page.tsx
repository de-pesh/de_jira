// app/admin/page.tsx
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { getPlatformStats } from "@/lib/db/db";
import { Sidebar } from "@/components/layout/Sidebar";

export const metadata = { title: "Platform Overview" };

export default async function AdminPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "super_admin") redirect("/dashboard");

  const stats = getPlatformStats();

  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", minHeight: "100vh" }}>
      <Sidebar session={session} />
      <main>
        {/* Replace with <SuperAdminClient stats={stats} /> */}
        <pre style={{ padding: 24, fontSize: 12, color: "#64748b" }}>
          Platform: {stats.totalCompanies} companies, {stats.totalUsers} users, {stats.totalTasks} tasks
        </pre>
      </main>
    </div>
  );
}
