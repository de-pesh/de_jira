// app/employees/page.tsx
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { getUsers } from "@/lib/db/db";
import { Sidebar } from "@/components/layout/Sidebar";

export const metadata = { title: "Employees" };

export default async function EmployeesPage() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role === "staff" || session.role === "manager") redirect("/tasks");

  const users = getUsers(session.companyId);
  const safeUsers = users.map(({ passwordHash: _, ...u }) => u);
  const pendingCount = safeUsers.filter(u => u.status === "pending").length;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", minHeight: "100vh" }}>
      <Sidebar session={session} pendingCount={pendingCount} />
      <main>
        {/* Replace with <EmployeeManagerClient users={safeUsers} session={session} /> */}
        <pre style={{ padding: 24, fontSize: 12, color: "#64748b" }}>
          {safeUsers.length} employees loaded — {pendingCount} pending approval
        </pre>
      </main>
    </div>
  );
}
