// app/api/users/[id]/approve/route.ts
// POST /api/users/:id/approve — approve a pending employee

import { NextRequest, NextResponse } from "next/server";
import { getUserById, updateUser, createActivityLog } from "@/lib/db/db";
import { requireAuth, requireSameCompany } from "@/lib/auth/rbac";

type Params = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "user:approve");
  if (error) return error;

  const user = getUserById(id);
  if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

  const companyError = requireSameCompany(session, user.companyId);
  if (companyError) return companyError;

  if (user.status !== "pending") {
    return NextResponse.json({ error: "User is not pending approval." }, { status: 400 });
  }

  updateUser(id, { status: "active" });

  createActivityLog({
    companyId: session.companyId,
    userId: session.userId,
    action: "user_approved",
    detail: `${session.name} approved ${user.name}`,
  });

  return NextResponse.json({ message: `${user.name} has been approved.` });
}
