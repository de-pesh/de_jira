// app/api/users/[id]/route.ts
// GET    /api/users/:id               — get user profile
// PATCH  /api/users/:id               — update user (admin)
// DELETE /api/users/:id               — remove user (admin)
// POST   /api/users/:id/approve       — approve pending user
// POST   /api/users/:id/reset-password — admin resets user password

import { NextRequest, NextResponse } from "next/server";
import { getUserById, updateUser, deleteUser, createActivityLog } from "@/lib/db/db";
import { requireAuth, requireSameCompany } from "@/lib/auth/rbac";
import { validate, parseBody } from "@/lib/validation/validate";
import { UpdateUserSchema, AdminResetPasswordSchema } from "@/lib/validation/schemas";
import { hashPassword } from "@/lib/auth/password";

type Params = { params: Promise<{ id: string }> };

// ─── GET /api/users/:id ──────────────────────────────────────
export async function GET(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "user:read:own");
  if (error) return error;

  // Users can read their own profile; others need user:read:all
  if (id !== session.userId) {
    const { error: permError } = await requireAuth(req, "user:read:all");
    if (permError) return permError;
  }

  const user = getUserById(id);
  if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

  const companyError = requireSameCompany(session, user.companyId);
  if (companyError) return companyError;

  const { passwordHash: _, ...safeUser } = user;
  return NextResponse.json({ user: safeUser });
}

// ─── PATCH /api/users/:id ────────────────────────────────────
export async function PATCH(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "user:update:any");
  if (error) return error;

  const user = getUserById(id);
  if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

  const companyError = requireSameCompany(session, user.companyId);
  if (companyError) return companyError;

  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(UpdateUserSchema, body);
  if (validationError) return validationError;

  const updated = updateUser(id, data);
  if (!updated) return NextResponse.json({ error: "User not found." }, { status: 404 });

  createActivityLog({
    companyId: session.companyId,
    userId: session.userId,
    action: "user_added",
    detail: `${session.name} updated profile for ${user.name}`,
  });

  const { passwordHash: _, ...safeUser } = updated;
  return NextResponse.json({ user: safeUser });
}

// ─── DELETE /api/users/:id ───────────────────────────────────
export async function DELETE(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "user:delete");
  if (error) return error;

  if (id === session.userId) {
    return NextResponse.json({ error: "You cannot delete your own account." }, { status: 400 });
  }

  const user = getUserById(id);
  if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

  const companyError = requireSameCompany(session, user.companyId);
  if (companyError) return companyError;

  deleteUser(id);

  createActivityLog({
    companyId: session.companyId,
    userId: session.userId,
    action: "user_removed",
    detail: `${session.name} removed ${user.name} from the team`,
  });

  return NextResponse.json({ message: "User removed." });
}
