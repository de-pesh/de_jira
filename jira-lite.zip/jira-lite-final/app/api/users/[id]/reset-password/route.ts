// app/api/users/[id]/reset-password/route.ts
// POST /api/users/:id/reset-password — admin sets a new password for a user

import { NextRequest, NextResponse } from "next/server";
import { getUserById, updateUser, createActivityLog } from "@/lib/db/db";
import { requireAuth, requireSameCompany } from "@/lib/auth/rbac";
import { validate, parseBody } from "@/lib/validation/validate";
import { z } from "zod";
import { hashPassword } from "@/lib/auth/password";

const Schema = z.object({
  newPassword: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Must contain an uppercase letter")
    .regex(/[0-9]/, "Must contain a number"),
});

type Params = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "user:reset-password");
  if (error) return error;

  const user = getUserById(id);
  if (!user) return NextResponse.json({ error: "User not found." }, { status: 404 });

  const companyError = requireSameCompany(session, user.companyId);
  if (companyError) return companyError;

  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(Schema, body);
  if (validationError) return validationError;

  const passwordHash = await hashPassword(data.newPassword);
  updateUser(id, { passwordHash });

  createActivityLog({
    companyId: session.companyId,
    userId: session.userId,
    action: "user_approved", // closest action type available
    detail: `${session.name} reset password for ${user.name}`,
  });

  return NextResponse.json({ message: `Password reset for ${user.name}.` });
}
