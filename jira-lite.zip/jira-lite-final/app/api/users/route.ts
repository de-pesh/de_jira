// app/api/users/route.ts
// GET  /api/users  — list employees (admin/manager)
// POST /api/users  — create new employee (admin only)

import { NextRequest, NextResponse } from "next/server";
import { getUsers, createUser } from "@/lib/db/db";
import { requireAuth } from "@/lib/auth/rbac";
import { validate, parseBody } from "@/lib/validation/validate";
import { CreateUserSchema } from "@/lib/validation/schemas";
import { hashPassword } from "@/lib/auth/password";
import { sendWelcomeEmail } from "@/lib/email/mailer";
import { createActivityLog } from "@/lib/db/db";

export async function GET(req: NextRequest) {
  const { session, error } = await requireAuth(req, "user:read:all");
  if (error) return error;

  const companyId = session.role === "super_admin" ? undefined : session.companyId;
  const users = getUsers(companyId).map(({ passwordHash: _, ...u }) => u); // strip password hash

  return NextResponse.json({ users });
}

export async function POST(req: NextRequest) {
  const { session, error } = await requireAuth(req, "user:create");
  if (error) return error;

  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(CreateUserSchema, body);
  if (validationError) return validationError;

  // Admins can only create users in their own company
  if (session.role !== "super_admin" && data.companyId !== session.companyId) {
    return NextResponse.json({ error: "Forbidden. Cannot create users for another company." }, { status: 403 });
  }

  const passwordHash = await hashPassword(data.password);

  const newUser = createUser({
    name: data.name,
    email: data.email,
    role: data.role,
    companyId: data.companyId,
    status: "active",
    passwordHash,
  });

  createActivityLog({
    companyId: data.companyId,
    userId: session.userId,
    action: "user_added",
    detail: `${session.name} added ${newUser.name} as ${newUser.role}`,
  });

  // Send welcome email (non-blocking)
  sendWelcomeEmail(newUser.email, newUser.name, data.password).catch(console.error);

  const { passwordHash: _, ...safeUser } = newUser;
  return NextResponse.json({ user: safeUser }, { status: 201 });
}
