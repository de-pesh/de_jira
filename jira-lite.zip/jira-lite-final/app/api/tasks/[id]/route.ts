// app/api/tasks/[id]/route.ts
// GET    /api/tasks/:id  — get task details
// PATCH  /api/tasks/:id  — update task
// DELETE /api/tasks/:id  — delete task

import { NextRequest, NextResponse } from "next/server";
import {
  getTaskById,
  updateTask,
  deleteTask,
  getUserById,
  createActivityLog,
} from "@/lib/db/db";
import { requireAuth, requireTaskAccess, requireSameCompany } from "@/lib/auth/rbac";
import { validate, parseBody } from "@/lib/validation/validate";
import { UpdateTaskSchema } from "@/lib/validation/schemas";

type Params = { params: Promise<{ id: string }> };

// ─── GET /api/tasks/:id ──────────────────────────────────────
export async function GET(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "task:read:own");
  if (error) return error;

  const task = getTaskById(id);
  if (!task) return NextResponse.json({ error: "Task not found." }, { status: 404 });

  const companyError = requireSameCompany(session, task.companyId);
  if (companyError) return companyError;

  // Staff can only see tasks they're involved in
  if (
    session.role === "staff" &&
    task.assignedToId !== session.userId &&
    task.createdById !== session.userId
  ) {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  // Attach user details for display
  const assignee = getUserById(task.assignedToId);
  const creator = getUserById(task.createdById);

  return NextResponse.json({ task, assignee, creator });
}

// ─── PATCH /api/tasks/:id ────────────────────────────────────
export async function PATCH(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "task:update:own");
  if (error) return error;

  const task = getTaskById(id);
  if (!task) return NextResponse.json({ error: "Task not found." }, { status: 404 });

  const accessError = requireTaskAccess(session, task, "update");
  if (accessError) return accessError;

  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(UpdateTaskSchema, body);
  if (validationError) return validationError;

  // If reassigning, verify new assignee exists in same company
  if (data.assignedToId) {
    const newAssignee = getUserById(data.assignedToId);
    if (!newAssignee) return NextResponse.json({ error: "Assigned user not found." }, { status: 404 });
    const companyError = requireSameCompany(session, newAssignee.companyId);
    if (companyError) return companyError;
  }

  const updated = updateTask(id, data);

  // Log meaningful changes
  const changes: string[] = [];
  if (data.status && data.status !== task.status) changes.push(`Status → ${data.status}`);
  if (data.priority && data.priority !== task.priority) changes.push(`Priority → ${data.priority}`);
  if (data.assignedToId && data.assignedToId !== task.assignedToId) {
    const newAssignee = getUserById(data.assignedToId);
    changes.push(`Assigned to ${newAssignee?.name ?? data.assignedToId}`);
  }

  if (changes.length > 0) {
    createActivityLog({
      companyId: session.companyId,
      taskId: id,
      userId: session.userId,
      action: data.status !== task.status ? "status_changed" : "task_updated",
      detail: changes.join(", "),
    });
  }

  return NextResponse.json({ task: updated });
}

// ─── DELETE /api/tasks/:id ───────────────────────────────────
export async function DELETE(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "task:delete:own");
  if (error) return error;

  const task = getTaskById(id);
  if (!task) return NextResponse.json({ error: "Task not found." }, { status: 404 });

  const accessError = requireTaskAccess(session, task, "delete");
  if (accessError) return accessError;

  deleteTask(id);

  createActivityLog({
    companyId: session.companyId,
    taskId: id,
    userId: session.userId,
    action: "task_deleted",
    detail: `Task "${task.title}" deleted`,
  });

  return NextResponse.json({ message: "Task deleted." });
}
