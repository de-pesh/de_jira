// app/api/tasks/[id]/comments/route.ts
// GET  /api/tasks/:id/comments — list comments on a task
// POST /api/tasks/:id/comments — add a comment

import { NextRequest, NextResponse } from "next/server";
import { getTaskById, getCommentsByTask, createComment, createActivityLog, getUserById } from "@/lib/db/db";
import { requireAuth, requireSameCompany } from "@/lib/auth/rbac";
import { validate, parseBody } from "@/lib/validation/validate";
import { CreateCommentSchema } from "@/lib/validation/schemas";

type Params = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "comment:create");
  if (error) return error;

  const task = getTaskById(id);
  if (!task) return NextResponse.json({ error: "Task not found." }, { status: 404 });

  const companyError = requireSameCompany(session, task.companyId);
  if (companyError) return companyError;

  const comments = getCommentsByTask(id).map((c) => ({
    ...c,
    author: getUserById(c.userId),
  }));

  return NextResponse.json({ comments });
}

export async function POST(req: NextRequest, { params }: Params) {
  const { id } = await params;
  const { session, error } = await requireAuth(req, "comment:create");
  if (error) return error;

  const task = getTaskById(id);
  if (!task) return NextResponse.json({ error: "Task not found." }, { status: 404 });

  const companyError = requireSameCompany(session, task.companyId);
  if (companyError) return companyError;

  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(CreateCommentSchema, body);
  if (validationError) return validationError;

  const comment = createComment({ taskId: id, userId: session.userId, body: data.body });

  createActivityLog({
    companyId: session.companyId,
    taskId: id,
    userId: session.userId,
    action: "comment_added",
    detail: `${session.name} commented on task "${task.title}"`,
  });

  return NextResponse.json({ comment }, { status: 201 });
}
