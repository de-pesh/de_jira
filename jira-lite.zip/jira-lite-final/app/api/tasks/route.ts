// app/api/tasks/route.ts
// GET  /api/tasks        — list tasks (filtered by role)
// POST /api/tasks        — create a task

import { NextRequest, NextResponse } from "next/server";
import { getTasks, createTask, getUserById, createActivityLog } from "@/lib/db/db";
import { requireAuth, requireSameCompany } from "@/lib/auth/rbac";
import { validate, parseBody } from "@/lib/validation/validate";
import { CreateTaskSchema, TaskFilterSchema } from "@/lib/validation/schemas";
import { sendTaskAssignedEmail } from "@/lib/email/mailer";

// ─── GET /api/tasks ─────────────────────────────────────────
export async function GET(req: NextRequest) {
  const { session, error } = await requireAuth(req, "task:read:own");
  if (error) return error;

  // Parse query params for filters
  const searchParams = Object.fromEntries(req.nextUrl.searchParams);
  const { data: filters, error: filterError } = validate(TaskFilterSchema, searchParams);
  if (filterError) return filterError;

  let tasks = getTasks(session.role === "super_admin" ? undefined : session.companyId);

  // Staff: can only see tasks assigned to them OR created by them
  if (session.role === "staff") {
    tasks = tasks.filter(
      (t) => t.assignedToId === session.userId || t.createdById === session.userId
    );
  }

  // Apply filters
  if (filters.status) tasks = tasks.filter((t) => t.status === filters.status);
  if (filters.priority) tasks = tasks.filter((t) => t.priority === filters.priority);
  if (filters.assignedToId) tasks = tasks.filter((t) => t.assignedToId === filters.assignedToId);
  if (filters.createdById) tasks = tasks.filter((t) => t.createdById === filters.createdById);
  if (filters.search) {
    const q = filters.search.toLowerCase();
    tasks = tasks.filter(
      (t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)
    );
  }

  // Pagination
  const total = tasks.length;
  const start = (filters.page - 1) * filters.limit;
  const paginated = tasks.slice(start, start + filters.limit);

  return NextResponse.json({
    tasks: paginated,
    pagination: { total, page: filters.page, limit: filters.limit, pages: Math.ceil(total / filters.limit) },
  });
}

// ─── POST /api/tasks ─────────────────────────────────────────
export async function POST(req: NextRequest) {
  const { session, error } = await requireAuth(req, "task:create");
  if (error) return error;

  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(CreateTaskSchema, body);
  if (validationError) return validationError;

  // Verify assignee exists and is in same company
  const assignee = getUserById(data.assignedToId);
  if (!assignee) {
    return NextResponse.json({ error: "Assigned user not found." }, { status: 404 });
  }

  const companyError = requireSameCompany(session, assignee.companyId);
  if (companyError) return companyError;

  // Staff can only assign to others in same company (already enforced above)
  const task = createTask({
    ...data,
    description: data.description ?? "",
    companyId: session.companyId,
    createdById: session.userId,
  });

  // Log activity
  createActivityLog({
    companyId: session.companyId,
    taskId: task.id,
    userId: session.userId,
    action: "task_created",
    detail: `Task "${task.title}" created and assigned to ${assignee.name}`,
  });

  // Notify assignee by email (non-blocking)
  sendTaskAssignedEmail(assignee.email, assignee.name, task.title, session.name, task.deadline).catch(
    console.error
  );

  return NextResponse.json({ task }, { status: 201 });
}
