// app/api/analytics/route.ts
// GET /api/analytics?scope=platform  — super admin only
// GET /api/analytics?scope=company   — company admin+

import { NextRequest, NextResponse } from "next/server";
import { getPlatformStats, getCompanyStats } from "@/lib/db/db";
import { requireAuth } from "@/lib/auth/rbac";

export async function GET(req: NextRequest) {
  const { session, error } = await requireAuth(req);
  if (error) return error;

  const scope = req.nextUrl.searchParams.get("scope") ?? "company";

  if (scope === "platform") {
    const { error: permError } = await requireAuth(req, "analytics:platform");
    if (permError) return permError;
    return NextResponse.json({ stats: getPlatformStats() });
  }

  // Company-level analytics
  const { error: permError } = await requireAuth(req, "analytics:company");
  if (permError) return permError;

  const companyId = req.nextUrl.searchParams.get("companyId") ?? session.companyId;

  // Only super admin can query other companies
  if (companyId !== session.companyId && session.role !== "super_admin") {
    return NextResponse.json({ error: "Forbidden." }, { status: 403 });
  }

  return NextResponse.json({ stats: getCompanyStats(companyId) });
}
