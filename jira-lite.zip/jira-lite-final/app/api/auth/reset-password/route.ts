// app/api/auth/reset-password/route.ts
import { NextRequest, NextResponse } from "next/server";
import { updateUser } from "@/lib/db/db";
import { verifyResetToken, consumeResetToken, hashPassword } from "@/lib/auth/password";
import { validate, parseBody } from "@/lib/validation/validate";
import { ResetPasswordSchema } from "@/lib/validation/schemas";

export async function POST(req: NextRequest) {
  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(ResetPasswordSchema, body);
  if (validationError) return validationError;

  const tokenData = verifyResetToken(data.token);
  if (!tokenData) {
    return NextResponse.json(
      { error: "Invalid or expired reset token. Please request a new one." },
      { status: 400 }
    );
  }

  const passwordHash = await hashPassword(data.password);
  const updated = updateUser(tokenData.userId, { passwordHash });

  if (!updated) {
    return NextResponse.json({ error: "User not found." }, { status: 404 });
  }

  consumeResetToken(data.token);

  return NextResponse.json({ message: "Password reset successfully. You can now log in." });
}
