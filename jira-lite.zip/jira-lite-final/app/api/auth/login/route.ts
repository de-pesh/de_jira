// app/api/auth/login/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getUserByEmail } from "@/lib/db/db";
import { verifyPassword } from "@/lib/auth/password";
import { setSessionCookie } from "@/lib/auth/session";
import { validate, parseBody } from "@/lib/validation/validate";
import { LoginSchema } from "@/lib/validation/schemas";

export async function POST(req: NextRequest) {
  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(LoginSchema, body);
  if (validationError) return validationError;

  const user = getUserByEmail(data.email);

  // Use same error message for both cases to prevent email enumeration
  const invalidError = NextResponse.json(
    { error: "Invalid email or password" },
    { status: 401 }
  );

  if (!user) return invalidError;
  if (user.status === "pending") {
    return NextResponse.json(
      { error: "Your account is pending approval. Please contact your admin." },
      { status: 403 }
    );
  }
  if (user.status === "suspended") {
    return NextResponse.json(
      { error: "Your account has been suspended. Please contact your admin." },
      { status: 403 }
    );
  }

  const passwordValid = await verifyPassword(data.password, user.passwordHash);
  if (!passwordValid) return invalidError;

  await setSessionCookie({
    userId: user.id,
    email: user.email,
    role: user.role,
    companyId: user.companyId,
    name: user.name,
  });

  return NextResponse.json({
    message: "Login successful",
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  });
}
