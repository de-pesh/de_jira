// app/api/auth/forgot-password/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getUserByEmail } from "@/lib/db/db";
import { generateResetToken } from "@/lib/auth/password";
import { sendPasswordResetEmail } from "@/lib/email/mailer";
import { validate, parseBody } from "@/lib/validation/validate";
import { ForgotPasswordSchema } from "@/lib/validation/schemas";

export async function POST(req: NextRequest) {
  const { body, error: bodyError } = await parseBody(req);
  if (bodyError) return bodyError;

  const { data, error: validationError } = validate(ForgotPasswordSchema, body);
  if (validationError) return validationError;

  // Always return success to prevent email enumeration
  const successResponse = NextResponse.json({
    message: "If an account with that email exists, a reset link has been sent.",
  });

  const user = getUserByEmail(data.email);
  if (!user) return successResponse;

  const token = generateResetToken(user.id, user.email);
  await sendPasswordResetEmail(user.email, user.name, token);

  return successResponse;
}
