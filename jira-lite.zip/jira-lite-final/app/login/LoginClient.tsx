"use client";
// app/login/LoginClient.tsx
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@/components/ui/Toast";

export default function LoginClient() {
  const router = useRouter();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  function validate() {
    const e: typeof errors = {};
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = "Valid email required";
    if (!password) e.password = "Password required";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(ev: React.FormEvent) {
    ev.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Login failed");
        setLoading(false);
        return;
      }
      toast.success("Welcome back!", `Signed in as ${data.user.name}`);
      const home: Record<string, string> = {
        super_admin: "/admin", company_admin: "/dashboard",
        manager: "/tasks", staff: "/tasks",
      };
      router.push(home[data.user.role] ?? "/tasks");
    } catch {
      toast.error("Network error", "Please check your connection.");
      setLoading(false);
    }
  }

  // — same visual as the HTML prototype, now wired —
  return (
    <div style={{ minHeight: "100vh", display: "grid", gridTemplateColumns: "1fr 1fr" }}>
      {/* Left panel omitted for brevity — import the HTML styles or use shared Layout */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: 48, background: "#fff" }}>
        <form onSubmit={handleSubmit} style={{ width: "100%", maxWidth: 360 }} noValidate>
          <h1 style={{ fontSize: 22, fontWeight: 600, letterSpacing: "-0.03em", marginBottom: 6 }}>Welcome back</h1>
          <p style={{ fontSize: 13.5, color: "#64748b", marginBottom: 32 }}>Sign in to your workspace</p>

          {/* Email */}
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: "block", fontSize: 12.5, fontWeight: 500, marginBottom: 6 }}>Email address</label>
            <input
              type="email" value={email} onChange={e => { setEmail(e.target.value); setErrors(p => ({...p, email: ""})); }}
              placeholder="you@company.com"
              style={{ width: "100%", height: 42, padding: "0 12px", fontSize: 14, border: `1.5px solid ${errors.email ? "#ef4444" : "#e2e8f0"}`, borderRadius: 8, outline: "none", fontFamily: "inherit" }}
            />
            {errors.email && <p style={{ fontSize: 11.5, color: "#ef4444", marginTop: 4 }}>{errors.email}</p>}
          </div>

          {/* Password */}
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <label style={{ fontSize: 12.5, fontWeight: 500 }}>Password</label>
              <a href="/forgot-password" style={{ fontSize: 12, color: "#2563eb" }}>Forgot password?</a>
            </div>
            <div style={{ position: "relative" }}>
              <input
                type={showPw ? "text" : "password"} value={password}
                onChange={e => { setPassword(e.target.value); setErrors(p => ({...p, password: ""})); }}
                placeholder="••••••••"
                style={{ width: "100%", height: 42, padding: "0 40px 0 12px", fontSize: 14, border: `1.5px solid ${errors.password ? "#ef4444" : "#e2e8f0"}`, borderRadius: 8, outline: "none", fontFamily: "inherit" }}
              />
              <button type="button" onClick={() => setShowPw(v => !v)}
                style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: "#94a3b8", fontSize: 13 }}>
                {showPw ? "Hide" : "Show"}
              </button>
            </div>
            {errors.password && <p style={{ fontSize: 11.5, color: "#ef4444", marginTop: 4 }}>{errors.password}</p>}
          </div>

          <button type="submit" disabled={loading}
            style={{ width: "100%", height: 42, background: loading ? "#93c5fd" : "#2563eb", color: "#fff", border: "none", borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: loading ? "not-allowed" : "pointer", fontFamily: "inherit" }}>
            {loading ? "Signing in…" : "Sign in"}
          </button>
        </form>
      </div>
    </div>
  );
}
