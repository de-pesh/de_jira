// app/login/page.tsx
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import LoginClient from "./LoginClient";

export const metadata = { title: "Sign In" };

export default async function LoginPage() {
  // Already logged in → redirect to their home
  const session = await getSession();
  if (session) {
    const home: Record<string, string> = {
      super_admin: "/admin",
      company_admin: "/dashboard",
      manager: "/tasks",
      staff: "/tasks",
    };
    redirect(home[session.role] ?? "/tasks");
  }
  return <LoginClient />;
}
