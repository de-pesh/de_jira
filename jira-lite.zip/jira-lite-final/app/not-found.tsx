// app/not-found.tsx  — shown for any unmatched route
import Link from "next/link";

export default function NotFound() {
  return (
    <div style={{
      minHeight: "100vh", display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      fontFamily: "var(--font-dm-sans, sans-serif)",
      background: "#f1f5f9", padding: 24, textAlign: "center",
    }}>
      {/* Logo */}
      <div style={{
        width: 40, height: 40, background: "#2563eb", borderRadius: 10,
        display: "flex", alignItems: "center", justifyContent: "center",
        marginBottom: 28,
      }}>
        <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
          <rect x="2" y="2" width="8" height="8" rx="2" fill="white" opacity="0.9"/>
          <rect x="12" y="2" width="8" height="8" rx="2" fill="white" opacity="0.5"/>
          <rect x="2" y="12" width="8" height="8" rx="2" fill="white" opacity="0.5"/>
          <rect x="12" y="12" width="8" height="8" rx="2" fill="white" opacity="0.25"/>
        </svg>
      </div>

      {/* Code */}
      <div style={{
        fontSize: 72, fontWeight: 700, letterSpacing: "-0.06em",
        color: "#e2e8f0", lineHeight: 1, marginBottom: 16,
        fontVariantNumeric: "tabular-nums",
      }}>404</div>

      <h1 style={{ fontSize: 20, fontWeight: 600, color: "#0f172a", letterSpacing: "-0.03em", marginBottom: 8 }}>
        Page not found
      </h1>
      <p style={{ fontSize: 14, color: "#64748b", maxWidth: 300, lineHeight: 1.6, marginBottom: 28 }}>
        This page doesn't exist or you don't have permission to view it.
      </p>

      <div style={{ display: "flex", gap: 10 }}>
        <Link href="/tasks" style={{
          fontSize: 13.5, fontWeight: 500, padding: "8px 18px",
          background: "#2563eb", color: "white", borderRadius: 8,
          textDecoration: "none", transition: "background 0.15s",
        }}>
          Go to Tasks
        </Link>
        <Link href="/login" style={{
          fontSize: 13.5, fontWeight: 500, padding: "8px 18px",
          background: "white", color: "#64748b", borderRadius: 8,
          textDecoration: "none", border: "1px solid #e2e8f0",
        }}>
          Sign In
        </Link>
      </div>
    </div>
  );
}
