"use client";
// app/error.tsx — Next.js error boundary for unhandled runtime errors

import { useEffect } from "react";

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

export default function GlobalError({ error, reset }: ErrorProps) {
  useEffect(() => {
    // Log to error tracking service here (e.g. Sentry)
    console.error("Unhandled error:", error);
  }, [error]);

  return (
    <div style={{
      minHeight: "100vh", display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      fontFamily: "var(--font-dm-sans, sans-serif)",
      background: "#f1f5f9", padding: 24, textAlign: "center",
    }}>
      <div style={{
        width: 48, height: 48, background: "#fef2f2", borderRadius: "50%",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 22, marginBottom: 20,
      }}>⚠️</div>

      <h1 style={{ fontSize: 19, fontWeight: 600, color: "#0f172a", letterSpacing: "-0.02em", marginBottom: 8 }}>
        Something went wrong
      </h1>
      <p style={{ fontSize: 13.5, color: "#64748b", maxWidth: 320, lineHeight: 1.6, marginBottom: 24 }}>
        An unexpected error occurred. Our team has been notified.
        {error.digest && (
          <span style={{ display: "block", marginTop: 6, fontFamily: "monospace", fontSize: 11, color: "#94a3b8" }}>
            Error ID: {error.digest}
          </span>
        )}
      </p>

      <div style={{ display: "flex", gap: 10 }}>
        <button onClick={reset} style={{
          fontSize: 13.5, fontWeight: 500, padding: "8px 18px",
          background: "#2563eb", color: "white", borderRadius: 8,
          border: "none", cursor: "pointer",
        }}>
          Try Again
        </button>
        <a href="/tasks" style={{
          fontSize: 13.5, fontWeight: 500, padding: "8px 18px",
          background: "white", color: "#64748b", borderRadius: 8,
          textDecoration: "none", border: "1px solid #e2e8f0",
        }}>
          Go Home
        </a>
      </div>
    </div>
  );
}
