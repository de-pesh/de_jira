// app/tasks/page.tsx
import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth/session";
import { getTasks, getUsers } from "@/lib/db/db";
import { Sidebar } from "@/components/layout/Sidebar";

export const metadata = { title: "Tasks" };

export default async function TasksPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  // Fetch tasks filtered by role
  let tasks = getTasks(session.role === "super_admin" ? undefined : session.companyId);
  if (session.role === "staff") {
    tasks = tasks.filter(t =>
      t.assignedToId === session.userId || t.createdById === session.userId
    );
  }

  const users = getUsers(session.companyId);
  const pendingCount = users.filter(u => u.status === "pending").length;

  // Strip password hashes before passing to client
  const safeUsers = users.map(({ passwordHash: _, ...u }) => u);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", minHeight: "100vh" }}>
      <Sidebar session={session} pendingCount={pendingCount} />
      <main>
        {/* TaskBoardClient receives pre-fetched data; mutations go via fetch("/api/tasks") */}
        <pre style={{ padding: 24, fontSize: 12, color: "#64748b" }}>
          {/* Replace this with <TaskBoardClient tasks={tasks} users={safeUsers} session={session} /> */}
          TaskBoard UI renders here — {tasks.length} tasks loaded for {session.name}
        </pre>
      </main>
    </div>
  );
}
